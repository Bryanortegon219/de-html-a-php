<ul>
<nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="inicio.php">inicio</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="clientes.php">clientes</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="productos.php">productos</a>
        <a class="py-2 link-body-emphasis text-decoration-none" href="mi perfil.php">mi perfil</a>
      </nav>
    </div>
</ul>
