<ul>
  <div class="nav-scroller py-1 mb-3 border-bottom">
    <nav class="nav nav-underline justify-content-between">
      <a class="nav-item nav-link link-body-emphasis active" href="inicio.php">inicio</a>
      <a class="nav-item nav-link link-body-emphasis" href="clientes.php">clientes</a>
      <a class="nav-item nav-link link-body-emphasis" href="productos.php">productos</a>
      <a class="nav-item nav-link link-body-emphasis" href="mi perfil.php">mi perfil</a>
    </nav>
  </div>
</div>
</ul>